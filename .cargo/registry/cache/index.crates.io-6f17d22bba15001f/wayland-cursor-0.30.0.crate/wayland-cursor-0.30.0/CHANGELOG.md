# CHANGELOG: wayland-cursor

## Unreleased

## 0.30.0 -- 27/12/2022

## 0.30.0-alpha1

Rework of the crate as a consequence of the rework of `wayland-client`.